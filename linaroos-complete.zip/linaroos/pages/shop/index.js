import { useState, useMemo, useEffect } from 'react'
import { useRouter } from 'next/router'
import SEOHead from '../../components/SEOHead'
import ProductCard from '../../components/ProductCard'
import { buildSEO } from '../../lib/seo'
import allProducts from '../../data/products.json'
import styles from '../../styles/Shop.module.css'

const CATEGORIES = ['All', 'Bouquets', 'Arrangements', 'Gift Boxes', 'Subscriptions']
const SORT_OPTIONS = [
  { value: 'featured', label: 'Featured' },
  { value: 'price-asc', label: 'Price: Low to High' },
  { value: 'price-desc', label: 'Price: High to Low' },
  { value: 'rating', label: 'Best Rated' },
]

export default function ShopPage() {
  const router = useRouter()
  const seo = buildSEO({ title: 'Shop', description: 'Browse our full collection of luxury bouquets, arrangements and gift boxes.', canonical: '/shop' })

  const [activeCategory, setActiveCategory] = useState('All')
  const [sortBy, setSortBy] = useState('featured')
  const [search, setSearch] = useState('')

  // Sync category from URL query
  useEffect(() => {
    if (router.query.category) setActiveCategory(router.query.category)
  }, [router.query.category])

  const filtered = useMemo(() => {
    let list = [...allProducts]

    if (activeCategory !== 'All') {
      list = list.filter(p => p.category === activeCategory)
    }
    if (search.trim()) {
      const q = search.toLowerCase()
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.shortDescription.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
      )
    }
    switch (sortBy) {
      case 'price-asc': list.sort((a, b) => a.price - b.price); break
      case 'price-desc': list.sort((a, b) => b.price - a.price); break
      case 'rating': list.sort((a, b) => b.rating - a.rating); break
      default: break
    }
    return list
  }, [activeCategory, sortBy, search])

  return (
    <>
      <SEOHead seo={seo} />

      {/* ── PAGE HEADER ── */}
      <div className={styles.pageHeader}>
        <div className="container">
          <p className={styles.eyebrow}>LinaRoos Collection</p>
          <h1 className={styles.pageTitle}>The Flower Shop</h1>
          <p className={styles.pageSub}>Every arrangement is a handcrafted piece of art.</p>
        </div>
      </div>

      <div className="container">
        {/* ── CONTROLS ── */}
        <div className={styles.controls}>
          {/* Search */}
          <div className={styles.searchWrap}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={styles.searchIcon}>
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
            <input
              type="search"
              placeholder="Search flowers..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className={styles.searchInput}
              aria-label="Search products"
            />
          </div>

          {/* Category filters */}
          <div className={styles.filters} role="list" aria-label="Category filters">
            {CATEGORIES.map(c => (
              <button
                key={c}
                role="listitem"
                className={`${styles.filterBtn} ${activeCategory === c ? styles.filterActive : ''}`}
                onClick={() => setActiveCategory(c)}
                aria-pressed={activeCategory === c}
              >
                {c}
              </button>
            ))}
          </div>

          {/* Sort */}
          <div className={styles.sortWrap}>
            <label htmlFor="sort-select" className={styles.sortLabel}>Sort:</label>
            <select
              id="sort-select"
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              className={styles.sortSelect}
            >
              {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
        </div>

        {/* ── COUNT ── */}
        <p className={styles.count} aria-live="polite">
          {filtered.length} {filtered.length === 1 ? 'arrangement' : 'arrangements'}
          {activeCategory !== 'All' && ` in ${activeCategory}`}
        </p>

        {/* ── GRID ── */}
        {filtered.length > 0 ? (
          <div className="grid-products" style={{ marginBottom: '80px' }}>
            {filtered.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
          </div>
        ) : (
          <div className={styles.empty}>
            <span className={styles.emptyIcon}>🌸</span>
            <h3>No arrangements found</h3>
            <p>Try a different search or browse all categories.</p>
            <button onClick={() => { setSearch(''); setActiveCategory('All') }} className="btn btn-outline" style={{ marginTop: '20px' }}>
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </>
  )
}
