import { useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import SEOHead from '../../components/SEOHead'
import ProductCard from '../../components/ProductCard'
import { buildSEO, buildProductSchema } from '../../lib/seo'
import { useCart } from '../../context/CartContext'
import allProducts from '../../data/products.json'
import styles from '../../styles/ProductDetail.module.css'

export default function ProductPage({ product, related }) {
  const { addItem } = useCart()
  const [qty, setQty] = useState(1)
  const [activeImg, setActiveImg] = useState(0)
  const [added, setAdded] = useState(false)

  const seo = buildSEO({
    title: product.name,
    description: product.shortDescription,
    canonical: `/shop/${product.slug}`,
    ogImage: product.image,
  })
  const schema = buildProductSchema(product)

  const handleAdd = () => {
    addItem(product, qty)
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  return (
    <>
      <SEOHead seo={seo} schema={schema} />

      <div className="container" style={{ paddingTop: '48px', paddingBottom: '80px' }}>
        {/* Breadcrumb */}
        <nav className="breadcrumb" aria-label="Breadcrumb">
          <Link href="/">Home</Link>
          <span className="breadcrumb-sep">›</span>
          <Link href="/shop">Shop</Link>
          <span className="breadcrumb-sep">›</span>
          <span>{product.category}</span>
          <span className="breadcrumb-sep">›</span>
          <span aria-current="page">{product.name}</span>
        </nav>

        {/* ── MAIN PRODUCT ── */}
        <div className={styles.product}>
          {/* Images */}
          <div className={styles.images}>
            <div className={styles.mainImg}>
              <Image
                src={product.images[activeImg] || product.image}
                alt={product.name}
                fill
                priority
                className={styles.mainImgEl}
                sizes="(max-width: 768px) 100vw, 50vw"
              />
              {product.badge && (
                <span className={`badge ${product.badge === 'Sale' ? 'badge-blush' : 'badge-gold'} ${styles.badge}`}>
                  {product.badge}
                </span>
              )}
            </div>
            {product.images.length > 1 && (
              <div className={styles.thumbs}>
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    className={`${styles.thumb} ${i === activeImg ? styles.thumbActive : ''}`}
                    onClick={() => setActiveImg(i)}
                    aria-label={`View image ${i + 1}`}
                    aria-pressed={i === activeImg}
                  >
                    <Image src={img} alt="" fill className={styles.thumbImg} sizes="80px" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className={styles.info}>
            <p className={styles.category}>{product.category}</p>
            <h1 className={styles.name}>{product.name}</h1>

            <div className={styles.ratingRow}>
              <span className="stars">{'★'.repeat(Math.round(product.rating))}{'☆'.repeat(5 - Math.round(product.rating))}</span>
              <span className={styles.ratingNum}>{product.rating}</span>
              <span className={styles.ratingCount}>({product.reviews} reviews)</span>
            </div>

            <div className={styles.priceRow}>
              {product.originalPrice && (
                <span className={styles.originalPrice}>€{product.originalPrice.toFixed(2)}</span>
              )}
              <span className={styles.price}>€{product.price.toFixed(2)}</span>
            </div>

            <div className={styles.divider} />

            <p className={styles.description}>{product.description}</p>

            {/* Details */}
            <div className={styles.details}>
              {Object.entries(product.details).map(([key, val]) => (
                <div key={key} className={styles.detailRow}>
                  <span className={styles.detailKey}>{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                  <span className={styles.detailVal}>{Array.isArray(val) ? val.join(', ') : val}</span>
                </div>
              ))}
            </div>

            <div className={styles.divider} />

            {/* Tags */}
            <div className={styles.tags}>
              {product.tags.map(tag => (
                <Link key={tag} href={`/shop?search=${tag}`} className={styles.tag}>{tag}</Link>
              ))}
            </div>

            {/* Add to cart */}
            <div className={styles.addRow}>
              <div className={styles.qtyWrap}>
                <button
                  className={styles.qtyBtn}
                  onClick={() => setQty(q => Math.max(1, q - 1))}
                  aria-label="Decrease quantity"
                  disabled={qty <= 1}
                >−</button>
                <span className={styles.qty} aria-label={`Quantity: ${qty}`}>{qty}</span>
                <button
                  className={styles.qtyBtn}
                  onClick={() => setQty(q => q + 1)}
                  aria-label="Increase quantity"
                >+</button>
              </div>
              <button
                className={`btn btn-primary ${styles.addBtn} ${added ? styles.addSuccess : ''}`}
                onClick={handleAdd}
                aria-label={`Add ${product.name} to cart`}
              >
                {added ? '✓ Added to Cart' : 'Add to Cart'}
              </button>
            </div>

            <Link href="/cart" className={`btn btn-gold ${styles.buyBtn}`}>
              Buy Now
            </Link>

            {/* Trust badges */}
            <div className={styles.trust}>
              {[
                { icon: '🚚', text: 'Free delivery over €75' },
                { icon: '🌿', text: 'Sustainably sourced' },
                { icon: '💌', text: 'Free handwritten card' },
              ].map((item) => (
                <div key={item.text} className={styles.trustItem}>
                  <span>{item.icon}</span>
                  <span>{item.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── RELATED ── */}
        {related.length > 0 && (
          <div className={styles.related}>
            <div className={styles.relatedHead}>
              <h2 className={styles.relatedTitle}>You May Also Love</h2>
              <Link href="/shop" className={styles.relatedLink}>View All →</Link>
            </div>
            <div className="grid-products">
              {related.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
            </div>
          </div>
        )}
      </div>
    </>
  )
}

export async function getStaticPaths() {
  const paths = allProducts.map(p => ({ params: { slug: p.slug } }))
  return { paths, fallback: false }
}

export async function getStaticProps({ params }) {
  const product = allProducts.find(p => p.slug === params.slug)
  if (!product) return { notFound: true }
  const related = allProducts
    .filter(p => p.id !== product.id && (p.category === product.category || p.tags.some(t => product.tags.includes(t))))
    .slice(0, 4)
  return { props: { product, related } }
}
