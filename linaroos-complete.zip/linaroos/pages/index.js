import Link from 'next/link'
import Image from 'next/image'
import { useState, useEffect } from 'react'
import SEOHead from '../components/SEOHead'
import ProductCard from '../components/ProductCard'
import { buildSEO, buildLocalBusinessSchema } from '../lib/seo'
import products from '../data/products.json'
import styles from '../styles/Home.module.css'

const HERO_IMAGES = [
  'https://images.unsplash.com/photo-1562690868-60bbe7293e94?w=1600&q=80',
  'https://images.unsplash.com/photo-1508610048659-a06b669e3321?w=1600&q=80',
  'https://images.unsplash.com/photo-1490750967868-88df5691cc4e?w=1600&q=80',
]

export default function Home() {
  const seo = buildSEO({ canonical: '/' })
  const schema = buildLocalBusinessSchema()
  const featured = products.filter(p => p.badge === 'Bestseller' || p.badge === 'Popular').slice(0, 4)
  const [heroIdx, setHeroIdx] = useState(0)

  useEffect(() => {
    const t = setInterval(() => setHeroIdx(i => (i + 1) % HERO_IMAGES.length), 5000)
    return () => clearInterval(t)
  }, [])

  return (
    <>
      <SEOHead seo={seo} schema={schema} />

      {/* ── HERO ── */}
      <section className={styles.hero} aria-label="Hero">
        {HERO_IMAGES.map((src, i) => (
          <div key={i} className={`${styles.heroSlide} ${i === heroIdx ? styles.heroActive : ''}`}>
            <Image src={src} alt="" fill priority={i === 0} className={styles.heroImg} quality={85} />
          </div>
        ))}
        <div className={styles.heroOverlay} />

        <div className={`container ${styles.heroContent}`}>
          <p className={styles.heroEyebrow}>Luxury Floral Studio</p>
          <h1 className={styles.heroTitle}>
            Flowers that<br />
            <em>speak for you</em>
          </h1>
          <p className={styles.heroSub}>
            Hand-crafted bouquets and arrangements for every moment that matters.
          </p>
          <div className={styles.heroCtas}>
            <Link href="/shop" className="btn btn-gold">
              Explore Collection
            </Link>
            <Link href="/contact" className={`btn btn-outline ${styles.heroOutline}`}>
              Bespoke Order
            </Link>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className={styles.scroll} aria-hidden>
          <div className={styles.scrollLine} />
          <span>Scroll</span>
        </div>

        {/* Slider dots */}
        <div className={styles.dots} role="tablist" aria-label="Hero slides">
          {HERO_IMAGES.map((_, i) => (
            <button key={i} className={`${styles.dot} ${i === heroIdx ? styles.dotActive : ''}`}
              onClick={() => setHeroIdx(i)} role="tab" aria-selected={i === heroIdx} aria-label={`Slide ${i + 1}`} />
          ))}
        </div>
      </section>

      {/* ── INTRO STRIP ── */}
      <section className={styles.introStrip} aria-label="Studio highlights">
        <div className="container">
          <div className={styles.stripGrid}>
            {[
              { icon: '✦', label: 'Hand-tied with love', desc: 'Every bouquet crafted by expert florists' },
              { icon: '✦', label: 'Premium flowers', desc: 'Sourced weekly from the finest growers' },
              { icon: '✦', label: 'Same-day delivery', desc: 'Amsterdam & surroundings, order by 12:00' },
              { icon: '✦', label: 'Bespoke orders', desc: 'Weddings, events & corporate commissions' },
            ].map((item, i) => (
              <div key={i} className={styles.stripItem}>
                <span className={styles.stripIcon}>{item.icon}</span>
                <strong className={styles.stripLabel}>{item.label}</strong>
                <p className={styles.stripDesc}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED PRODUCTS ── */}
      <section className={`section ${styles.featured}`} aria-labelledby="featured-title">
        <div className="container">
          <div className={`text-center ${styles.sectionHead}`}>
            <p className={styles.eyebrow}>Our Bestsellers</p>
            <h2 id="featured-title">Most Loved Arrangements</h2>
            <p className={styles.sectionSub}>Each piece is a love letter in flowers.</p>
          </div>

          <div className="grid-products">
            {featured.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
          </div>

          <div className={styles.viewAll}>
            <Link href="/shop" className="btn btn-outline">View Full Collection</Link>
          </div>
        </div>
      </section>

      {/* ── SPLIT FEATURE ── */}
      <section className={styles.splitSection} aria-label="About feature">
        <div className={styles.splitImg}>
          <Image
            src="https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=900&q=80"
            alt="Florist at work"
            fill
            className={styles.splitImgEl}
          />
        </div>
        <div className={styles.splitContent}>
          <p className={styles.eyebrow}>Our Philosophy</p>
          <h2>Where craft<br />meets intention</h2>
          <p>At LinaRoos, we believe that flowers are more than decoration — they are a language. Each arrangement is composed thoughtfully, balancing colour, texture, and fragrance to create something truly unforgettable.</p>
          <p style={{ marginTop: '16px' }}>We work only with seasonal, sustainably sourced blooms from growers we trust, so every petal is as kind to the earth as it is to the eye.</p>
          <Link href="/about" className={`btn btn-primary ${styles.splitBtn}`}>
            Our Story
          </Link>
        </div>
      </section>

      {/* ── CATEGORIES GRID ── */}
      <section className={`section ${styles.catsSection}`} aria-labelledby="cats-title">
        <div className="container">
          <div className={`text-center ${styles.sectionHead}`}>
            <p className={styles.eyebrow}>Shop by Category</p>
            <h2 id="cats-title">Find Your Perfect Bloom</h2>
          </div>

          <div className={styles.catsGrid}>
            {[
              { label: 'Bouquets', href: '/shop?category=Bouquets', img: 'https://images.unsplash.com/photo-1487530811015-780c71e5c7b8?w=600&q=80' },
              { label: 'Arrangements', href: '/shop?category=Arrangements', img: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=600&q=80' },
              { label: 'Gift Boxes', href: '/shop?category=Gift+Boxes', img: 'https://images.unsplash.com/photo-1549429218-4b3abe9c55d2?w=600&q=80' },
              { label: 'Subscriptions', href: '/shop?category=Subscriptions', img: 'https://images.unsplash.com/photo-1563241527-3004b7be0ffd?w=600&q=80' },
            ].map((cat) => (
              <Link key={cat.label} href={cat.href} className={styles.catCard}>
                <Image src={cat.img} alt={cat.label} fill className={styles.catImg} />
                <div className={styles.catOverlay} />
                <span className={styles.catLabel}>{cat.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className={styles.testimonials} aria-labelledby="reviews-title">
        <div className="container">
          <div className={`text-center ${styles.sectionHead}`}>
            <p className={styles.eyebrow}>Reviews</p>
            <h2 id="reviews-title">What Our Customers Say</h2>
          </div>
          <div className={styles.reviewGrid}>
            {[
              { name: 'Emma V.', stars: 5, text: 'The most beautiful bouquet I have ever received. The flowers were fresh, luxurious, and the packaging was divine. Will be ordering again!' },
              { name: 'Sophie D.', stars: 5, text: 'LinaRoos did our wedding flowers and they were absolutely breathtaking. Every single arrangement was perfect, and the team was wonderful to work with.' },
              { name: 'Lily M.', stars: 5, text: 'Monthly subscription is a joy. Each delivery is a surprise, and the quality is consistently outstanding. My home has never looked better.' },
            ].map((r, i) => (
              <div key={i} className={styles.review}>
                <div className={styles.reviewStars}>{'★'.repeat(r.stars)}</div>
                <p className={styles.reviewText}>"{r.text}"</p>
                <p className={styles.reviewName}>— {r.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ── */}
      <section className={styles.ctaBanner} aria-label="Call to action">
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2 className={styles.ctaTitle}>Something special in mind?</h2>
              <p className={styles.ctaSub}>We create bespoke arrangements for weddings, events, and corporate clients.</p>
            </div>
            <Link href="/contact" className="btn btn-gold">Get in Touch</Link>
          </div>
        </div>
      </section>
    </>
  )
}
