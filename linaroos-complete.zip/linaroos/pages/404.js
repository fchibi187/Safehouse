import Link from 'next/link'
import Head from 'next/head'
import styles from '../styles/404.module.css'

export default function NotFound() {
  return (
    <>
      <Head>
        <title>404 – Page Not Found | LinaRoos</title>
      </Head>
      <div className={styles.page}>
        <span className={styles.icon}>🌸</span>
        <h1 className={styles.title}>404</h1>
        <p className={styles.sub}>This page has wilted away.</p>
        <p className={styles.desc}>The page you're looking for doesn't exist or has been moved.</p>
        <div className={styles.actions}>
          <Link href="/" className="btn btn-primary">Back to Home</Link>
          <Link href="/shop" className="btn btn-ghost">Shop Now</Link>
        </div>
      </div>
    </>
  )
}
