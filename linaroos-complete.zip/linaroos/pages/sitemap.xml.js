// pages/sitemap.xml.js
// Generates a dynamic XML sitemap at build time (or on-demand via ISR).

import products from '../data/products.json'
import { SITE } from '../lib/seo'

const STATIC_PAGES = [
  { path: '/', priority: '1.0', changefreq: 'weekly' },
  { path: '/shop', priority: '0.9', changefreq: 'daily' },
  { path: '/about', priority: '0.7', changefreq: 'monthly' },
  { path: '/contact', priority: '0.6', changefreq: 'monthly' },
]

function generateSitemap() {
  const productPages = products.map((p) => ({
    path: `/shop/${p.slug}`,
    priority: '0.8',
    changefreq: 'weekly',
  }))

  const allPages = [...STATIC_PAGES, ...productPages]
  const now = new Date().toISOString()

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
${allPages
  .map(
    (p) => `  <url>
    <loc>${SITE.url}${p.path}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>${p.changefreq}</changefreq>
    <priority>${p.priority}</priority>
  </url>`
  )
  .join('\n')}
${products
  .map(
    (p) => `  <url>
    <loc>${SITE.url}/shop/${p.slug}</loc>
    <lastmod>${now}</lastmod>
    <image:image>
      <image:loc>${p.image}</image:loc>
      <image:title>${p.name}</image:title>
    </image:image>
  </url>`
  )
  .join('\n')}
</urlset>`
}

export default function Sitemap() {
  // This component is never rendered – only the getServerSideProps matters
  return null
}

export function getServerSideProps({ res }) {
  res.setHeader('Content-Type', 'text/xml')
  res.setHeader('Cache-Control', 'public, s-maxage=3600, stale-while-revalidate=86400')
  res.write(generateSitemap())
  res.end()
  return { props: {} }
}
