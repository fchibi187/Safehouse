import { useState } from 'react'
import Link from 'next/link'
import SEOHead from '../components/SEOHead'
import { buildSEO } from '../lib/seo'
import { useCart } from '../context/CartContext'
import styles from '../styles/Checkout.module.css'

const STEPS = ['Details', 'Delivery', 'Payment']

export default function CheckoutPage() {
  const seo = buildSEO({ title: 'Checkout', canonical: '/checkout', noIndex: true })
  const { items, total, clearCart } = useCart()
  const [step, setStep] = useState(0)
  const [submitting, setSubmitting] = useState(false)
  const [done, setDone] = useState(false)

  const shipping = total >= 75 ? 0 : 7.5

  const [form, setForm] = useState({
    firstName: '', lastName: '', email: '', phone: '',
    address: '', apartment: '', city: '', postcode: '', country: 'NL',
    note: '', giftMessage: '',
    sameAsBilling: true,
    cardNumber: '', cardExpiry: '', cardCvc: '', cardName: '',
  })

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (step < 2) { setStep(s => s + 1); return }
    setSubmitting(true)
    // In production: call /api/create-payment-intent (Stripe)
    await new Promise(r => setTimeout(r, 1800))
    clearCart()
    setDone(true)
    setSubmitting(false)
  }

  if (items.length === 0 && !done) {
    return (
      <>
        <SEOHead seo={seo} />
        <div className={styles.empty}>
          <h1>Your cart is empty</h1>
          <Link href="/shop" className="btn btn-primary">Shop Now</Link>
        </div>
      </>
    )
  }

  if (done) {
    return (
      <>
        <SEOHead seo={seo} />
        <div className={styles.success}>
          <div className={styles.successIcon}>🌸</div>
          <h1>Thank you, {form.firstName}!</h1>
          <p>Your order has been placed. A confirmation email has been sent to <strong>{form.email}</strong>.</p>
          <p className={styles.successSub}>We'll begin preparing your arrangement right away. Expected delivery: <strong>tomorrow before 18:00</strong>.</p>
          <Link href="/shop" className="btn btn-primary">Continue Shopping</Link>
        </div>
      </>
    )
  }

  return (
    <>
      <SEOHead seo={seo} />
      <div className="container" style={{ paddingTop: '48px', paddingBottom: '80px' }}>
        <div className={styles.header}>
          <Link href="/" className={styles.logoLink}>
            <span className={styles.logoScript}>Lina</span>
            <span>🌸</span>
            <span className={styles.logoScript}>oos</span>
          </Link>
        </div>

        {/* Progress */}
        <div className={styles.progress} role="list" aria-label="Checkout steps">
          {STEPS.map((s, i) => (
            <div key={s} role="listitem" className={`${styles.progressStep} ${i <= step ? styles.progressActive : ''} ${i < step ? styles.progressDone : ''}`}>
              <div className={styles.progressDot}>
                {i < step ? '✓' : i + 1}
              </div>
              <span className={styles.progressLabel}>{s}</span>
              {i < STEPS.length - 1 && <div className={styles.progressLine} />}
            </div>
          ))}
        </div>

        <div className={styles.layout}>
          <form onSubmit={handleSubmit} className={styles.form} noValidate>

            {/* ── STEP 0: DETAILS ── */}
            {step === 0 && (
              <div className={styles.section}>
                <h2 className={styles.sectionTitle}>Contact Details</h2>
                <div className={styles.row2}>
                  <Field label="First Name" value={form.firstName} onChange={set('firstName')} required />
                  <Field label="Last Name" value={form.lastName} onChange={set('lastName')} required />
                </div>
                <Field label="Email Address" type="email" value={form.email} onChange={set('email')} required />
                <Field label="Phone Number" type="tel" value={form.phone} onChange={set('phone')} />
                <Field label="Gift Message (optional)" value={form.giftMessage} onChange={set('giftMessage')} as="textarea" rows={3} placeholder="We'll include this on a handwritten card…" />
              </div>
            )}

            {/* ── STEP 1: DELIVERY ── */}
            {step === 1 && (
              <div className={styles.section}>
                <h2 className={styles.sectionTitle}>Delivery Address</h2>
                <Field label="Street Address" value={form.address} onChange={set('address')} required />
                <Field label="Apartment / Suite (optional)" value={form.apartment} onChange={set('apartment')} />
                <div className={styles.row2}>
                  <Field label="City" value={form.city} onChange={set('city')} required />
                  <Field label="Postcode" value={form.postcode} onChange={set('postcode')} required />
                </div>
                <div className={styles.fieldWrap}>
                  <label>Country</label>
                  <select value={form.country} onChange={set('country')} required>
                    <option value="NL">Netherlands</option>
                    <option value="BE">Belgium</option>
                    <option value="DE">Germany</option>
                    <option value="GB">United Kingdom</option>
                  </select>
                </div>
                <Field label="Delivery Note (optional)" value={form.note} onChange={set('note')} as="textarea" rows={2} placeholder="e.g. Leave at the door, ring doorbell…" />
              </div>
            )}

            {/* ── STEP 2: PAYMENT ── */}
            {step === 2 && (
              <div className={styles.section}>
                <h2 className={styles.sectionTitle}>Payment</h2>
                <div className={styles.stripeNote}>
                  <span>🔒</span>
                  <span>Payments are processed securely via Stripe. We never store your card details.</span>
                </div>
                <Field label="Name on Card" value={form.cardName} onChange={set('cardName')} required />
                <Field label="Card Number" value={form.cardNumber} onChange={set('cardNumber')} placeholder="1234 5678 9012 3456" required />
                <div className={styles.row2}>
                  <Field label="Expiry (MM/YY)" value={form.cardExpiry} onChange={set('cardExpiry')} placeholder="MM/YY" required />
                  <Field label="CVC" value={form.cardCvc} onChange={set('cardCvc')} placeholder="123" required />
                </div>
                {/* In production, replace the above with <CardElement /> from @stripe/react-stripe-js */}
              </div>
            )}

            <div className={styles.nav}>
              {step > 0 && (
                <button type="button" className={`btn btn-ghost`} onClick={() => setStep(s => s - 1)}>
                  ← Back
                </button>
              )}
              <button
                type="submit"
                className={`btn btn-primary ${styles.nextBtn}`}
                disabled={submitting}
              >
                {submitting ? 'Processing…' : step < 2 ? `Continue to ${STEPS[step + 1]}` : `Place Order · €${(total + shipping).toFixed(2)}`}
              </button>
            </div>
          </form>

          {/* Order summary sidebar */}
          <div className={styles.sidebar}>
            <h3 className={styles.sidebarTitle}>Order Summary</h3>
            <div className={styles.sidebarItems}>
              {items.map(item => (
                <div key={item.id} className={styles.sidebarItem}>
                  <div className={styles.sidebarItemInfo}>
                    <span className={styles.sidebarItemQty}>{item.quantity}×</span>
                    <span className={styles.sidebarItemName}>{item.name}</span>
                  </div>
                  <span className={styles.sidebarItemPrice}>€{(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
            <div className={styles.sidebarDivider} />
            <div className={styles.sidebarRow}><span>Subtotal</span><span>€{total.toFixed(2)}</span></div>
            <div className={styles.sidebarRow}><span>Shipping</span><span>{shipping === 0 ? 'Free' : `€${shipping.toFixed(2)}`}</span></div>
            <div className={styles.sidebarDivider} />
            <div className={`${styles.sidebarRow} ${styles.sidebarTotal}`}>
              <span>Total</span><span>€{(total + shipping).toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

function Field({ label, as: Tag = 'input', ...props }) {
  return (
    <div style={{ marginBottom: '16px' }}>
      <label style={{ display: 'block', marginBottom: '6px', fontSize: '11px', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>
        {label}
      </label>
      <Tag {...props} style={{ width: '100%' }} />
    </div>
  )
}
