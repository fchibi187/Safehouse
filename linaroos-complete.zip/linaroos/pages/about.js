import Image from 'next/image'
import Link from 'next/link'
import SEOHead from '../components/SEOHead'
import { buildSEO } from '../lib/seo'
import styles from '../styles/About.module.css'

export default function AboutPage() {
  const seo = buildSEO({
    title: 'Our Story',
    description: 'Learn about LinaRoos – a luxury floral studio founded on the belief that flowers should be as intentional as the moments they celebrate.',
    canonical: '/about',
  })

  return (
    <>
      <SEOHead seo={seo} />

      {/* ── HERO ── */}
      <div className={styles.hero}>
        <Image
          src="https://images.unsplash.com/photo-1562690868-60bbe7293e94?w=1600&q=80"
          alt="LinaRoos floral studio"
          fill priority className={styles.heroImg}
        />
        <div className={styles.heroOverlay} />
        <div className={`container ${styles.heroContent}`}>
          <p className={styles.eyebrow}>Est. 2018 · Amsterdam</p>
          <h1 className={styles.heroTitle}>Where every petal<br /><em>tells a story</em></h1>
        </div>
      </div>

      {/* ── INTRO ── */}
      <section className={`section ${styles.intro}`}>
        <div className="container">
          <div className={styles.introGrid}>
            <div className={styles.introText}>
              <p className={styles.eyebrow}>Our Story</p>
              <h2>Born from a love of beauty</h2>
              <p>LinaRoos began in a small Amsterdam kitchen in 2018, when Lina — a self-taught florist with a background in fine art — started creating arrangements for friends and neighbours who couldn't find anything truly beautiful at the local shops.</p>
              <p>Word spread. A market stall became a studio. A studio became a beloved destination for those who believe that the finest things in life are worth the care.</p>
              <p>Today, LinaRoos is a full-service floral atelier, crafting arrangements for intimate birthdays and grand weddings alike — always with the same intention: to make every bloom feel personal.</p>
            </div>
            <div className={styles.introImgWrap}>
              <Image
                src="https://images.unsplash.com/photo-1508610048659-a06b669e3321?w=700&q=80"
                alt="Lina at work"
                fill
                className={styles.introImg}
              />
            </div>
          </div>
        </div>
      </section>

      {/* ── VALUES ── */}
      <section className={styles.values}>
        <div className="container">
          <div className={`text-center ${styles.valuesHead}`}>
            <p className={styles.eyebrow}>What We Believe</p>
            <h2>Our Values</h2>
          </div>
          <div className={styles.valuesGrid}>
            {[
              { icon: '🌿', title: 'Sustainability', text: 'We source only from certified sustainable growers, using seasonal blooms and minimal packaging.' },
              { icon: '✦', title: 'Craftsmanship', text: 'Every bouquet is hand-tied by our florists. No templates, no shortcuts – only genuine care.' },
              { icon: '💌', title: 'Intention', text: 'Flowers are a love language. We take time to understand each customer\'s moment and create accordingly.' },
              { icon: '🎨', title: 'Artistry', text: 'With a fine art background, Lina brings a painterly eye to every arrangement, balancing colour and form.' },
            ].map((v) => (
              <div key={v.title} className={styles.valueCard}>
                <span className={styles.valueIcon}>{v.icon}</span>
                <h3 className={styles.valueTitle}>{v.title}</h3>
                <p className={styles.valueText}>{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PROCESS ── */}
      <section id="process" className={`section ${styles.process}`}>
        <div className="container">
          <div className={`text-center ${styles.processHead}`}>
            <p className={styles.eyebrow}>How We Work</p>
            <h2>The LinaRoos Process</h2>
          </div>
          <div className={styles.processSteps}>
            {[
              { n: '01', title: 'Source', text: 'Fresh from our trusted growers, seasonal blooms arrive each Monday and Thursday.' },
              { n: '02', title: 'Select', text: 'Our florists hand-pick stems at peak freshness, looking for colour, texture and longevity.' },
              { n: '03', title: 'Compose', text: 'Each arrangement is composed from scratch, guided by the occasion and your preferences.' },
              { n: '04', title: 'Deliver', text: 'Wrapped beautifully and delivered fresh to your door, same-day within Amsterdam.' },
            ].map((s) => (
              <div key={s.n} className={styles.processStep}>
                <span className={styles.processNum}>{s.n}</span>
                <div className={styles.processLine} />
                <h3 className={styles.processTitle}>{s.title}</h3>
                <p className={styles.processText}>{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TEAM ── */}
      <section className={styles.team}>
        <div className="container">
          <div className={`text-center ${styles.processHead}`}>
            <p className={styles.eyebrow}>The Studio</p>
            <h2>Meet the Team</h2>
          </div>
          <div className={styles.teamGrid}>
            {[
              { name: 'Lina Roos', role: 'Founder & Head Florist', img: 'https://images.unsplash.com/photo-1487530811015-780c71e5c7b8?w=400&q=80' },
              { name: 'Sophie V.', role: 'Senior Florist', img: 'https://images.unsplash.com/photo-1490750967868-88df5691cc4e?w=400&q=80' },
              { name: 'Mara D.', role: 'Event Specialist', img: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=400&q=80' },
            ].map((m) => (
              <div key={m.name} className={styles.teamMember}>
                <div className={styles.teamImgWrap}>
                  <Image src={m.img} alt={m.name} fill className={styles.teamImg} />
                </div>
                <h3 className={styles.teamName}>{m.name}</h3>
                <p className={styles.teamRole}>{m.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className={styles.cta}>
        <div className="container">
          <h2>Ready to find your arrangement?</h2>
          <p>Browse our full collection or get in touch for a bespoke commission.</p>
          <div className={styles.ctaBtns}>
            <Link href="/shop" className="btn btn-primary">Shop Now</Link>
            <Link href="/contact" className="btn btn-ghost">Contact Us</Link>
          </div>
        </div>
      </section>
    </>
  )
}
