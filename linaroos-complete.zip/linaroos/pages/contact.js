import { useState } from 'react'
import SEOHead from '../components/SEOHead'
import { buildSEO } from '../lib/seo'
import styles from '../styles/Contact.module.css'

export default function ContactPage() {
  const seo = buildSEO({
    title: 'Contact',
    description: 'Get in touch with LinaRoos for bespoke orders, wedding commissions, or any enquiry.',
    canonical: '/contact',
  })

  const [form, setForm] = useState({ name: '', email: '', subject: 'General enquiry', message: '' })
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    await new Promise(r => setTimeout(r, 1200))
    setSent(true)
    setLoading(false)
  }

  return (
    <>
      <SEOHead seo={seo} />

      <div className={styles.pageHeader}>
        <div className="container">
          <p className={styles.eyebrow}>Get in Touch</p>
          <h1 className={styles.pageTitle}>Contact Us</h1>
          <p className={styles.pageSub}>We'd love to hear from you.</p>
        </div>
      </div>

      <div className="container" style={{ paddingTop: '64px', paddingBottom: '80px' }}>
        <div className={styles.layout}>

          {/* Info */}
          <div className={styles.info}>
            <div className={styles.infoSection}>
              <h2 className={styles.infoTitle}>The Studio</h2>
              <address className={styles.address}>
                <p>Bloemenlaan 12</p>
                <p>1012 AB Amsterdam</p>
                <p><a href="tel:+31200000000">+31 20 000 0000</a></p>
                <p><a href="mailto:hello@linaroos.nl">hello@linaroos.nl</a></p>
              </address>
            </div>

            <div className={styles.infoSection}>
              <h3 className={styles.infoSubtitle}>Opening Hours</h3>
              <div className={styles.hours}>
                <div className={styles.hourRow}><span>Mon – Fri</span><span>09:00 – 18:00</span></div>
                <div className={styles.hourRow}><span>Saturday</span><span>10:00 – 16:00</span></div>
                <div className={styles.hourRow}><span>Sunday</span><span>Closed</span></div>
              </div>
            </div>

            <div className={styles.infoSection} id="bespoke">
              <h3 className={styles.infoSubtitle}>Bespoke Orders</h3>
              <p className={styles.infoText}>For weddings, events or corporate commissions, please contact us at least 2 weeks in advance. We'll arrange a consultation to discuss your vision.</p>
            </div>

            <div className={styles.infoSection} id="weddings">
              <h3 className={styles.infoSubtitle}>Weddings</h3>
              <p className={styles.infoText}>From bridal bouquets to full venue styling, we offer a complete wedding floristry service. Enquire early — our calendar books out quickly.</p>
            </div>
          </div>

          {/* Form */}
          <div className={styles.formWrap}>
            {sent ? (
              <div className={styles.success}>
                <span className={styles.successIcon}>🌸</span>
                <h2>Message Sent!</h2>
                <p>Thank you for reaching out. We'll be in touch within one business day.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className={styles.form} noValidate>
                <h2 className={styles.formTitle}>Send a Message</h2>

                <div className={styles.fieldGroup}>
                  <div className={styles.field}>
                    <label>Your Name</label>
                    <input type="text" value={form.name} onChange={set('name')} required placeholder="Your full name" />
                  </div>
                  <div className={styles.field}>
                    <label>Email Address</label>
                    <input type="email" value={form.email} onChange={set('email')} required placeholder="you@example.com" />
                  </div>
                </div>

                <div className={styles.field}>
                  <label>Subject</label>
                  <select value={form.subject} onChange={set('subject')}>
                    <option>General enquiry</option>
                    <option>Wedding consultation</option>
                    <option>Bespoke order</option>
                    <option>Corporate order</option>
                    <option>Subscription</option>
                    <option>Other</option>
                  </select>
                </div>

                <div className={styles.field}>
                  <label>Message</label>
                  <textarea value={form.message} onChange={set('message')} required rows={6} placeholder="Tell us about your occasion, preferences, and any specific requests…" />
                </div>

                <button type="submit" className={`btn btn-primary ${styles.submitBtn}`} disabled={loading}>
                  {loading ? 'Sending…' : 'Send Message →'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
