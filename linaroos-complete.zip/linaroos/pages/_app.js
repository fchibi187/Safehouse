import '../styles/globals.css'
import { useRouter } from 'next/router'
import { CartProvider } from '../context/CartContext'
import Layout from '../components/Layout'

export default function App({ Component, pageProps }) {
  const router = useRouter()
  const isAdmin = router.pathname.startsWith('/admin')

  return (
    <CartProvider>
      {isAdmin ? (
        <Component {...pageProps} />
      ) : (
        <Layout>
          <Component {...pageProps} />
        </Layout>
      )}
    </CartProvider>
  )
}
