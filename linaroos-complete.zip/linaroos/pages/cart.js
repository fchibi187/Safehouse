import Link from 'next/link'
import Image from 'next/image'
import SEOHead from '../components/SEOHead'
import { buildSEO } from '../lib/seo'
import { useCart } from '../context/CartContext'
import styles from '../styles/Cart.module.css'

export default function CartPage() {
  const seo = buildSEO({ title: 'Your Cart', canonical: '/cart', noIndex: true })
  const { items, total, updateQuantity, removeItem, clearCart } = useCart()

  const shipping = total >= 75 ? 0 : 7.5
  const grandTotal = total + shipping

  if (items.length === 0) {
    return (
      <>
        <SEOHead seo={seo} />
        <div className={styles.empty}>
          <span className={styles.emptyIcon}>🌸</span>
          <h1>Your cart is empty</h1>
          <p>Discover our beautiful arrangements and find your perfect bloom.</p>
          <Link href="/shop" className="btn btn-primary">Shop the Collection</Link>
        </div>
      </>
    )
  }

  return (
    <>
      <SEOHead seo={seo} />
      <div className="container" style={{ paddingTop: '48px', paddingBottom: '80px' }}>
        <div className={styles.header}>
          <h1 className={styles.title}>Your Cart</h1>
          <button onClick={clearCart} className={styles.clearBtn}>Clear cart</button>
        </div>

        <div className={styles.layout}>
          {/* Items */}
          <div className={styles.items}>
            {items.map((item) => (
              <div key={item.id} className={styles.item}>
                <div className={styles.itemImg}>
                  <Image src={item.image} alt={item.name} fill className={styles.itemImgEl} sizes="100px" />
                </div>
                <div className={styles.itemInfo}>
                  <p className={styles.itemCat}>{item.category}</p>
                  <Link href={`/shop/${item.slug}`} className={styles.itemName}>{item.name}</Link>
                  <p className={styles.itemSub}>{item.shortDescription}</p>
                </div>
                <div className={styles.itemControls}>
                  <div className={styles.qtyWrap}>
                    <button className={styles.qtyBtn} onClick={() => updateQuantity(item.id, item.quantity - 1)} aria-label="Decrease">−</button>
                    <span className={styles.qty}>{item.quantity}</span>
                    <button className={styles.qtyBtn} onClick={() => updateQuantity(item.id, item.quantity + 1)} aria-label="Increase">+</button>
                  </div>
                  <p className={styles.itemPrice}>€{(item.price * item.quantity).toFixed(2)}</p>
                  <button className={styles.removeBtn} onClick={() => removeItem(item.id)} aria-label={`Remove ${item.name}`}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className={styles.summary}>
            <h2 className={styles.summaryTitle}>Order Summary</h2>

            <div className={styles.summaryRows}>
              <div className={styles.summaryRow}>
                <span>Subtotal</span>
                <span>€{total.toFixed(2)}</span>
              </div>
              <div className={styles.summaryRow}>
                <span>Shipping</span>
                <span>{shipping === 0 ? 'Free' : `€${shipping.toFixed(2)}`}</span>
              </div>
              {shipping > 0 && (
                <p className={styles.shippingNote}>
                  Add €{(75 - total).toFixed(2)} more for free shipping!
                </p>
              )}
            </div>

            <div className={styles.divider} />

            <div className={`${styles.summaryRow} ${styles.total}`}>
              <span>Total</span>
              <span>€{grandTotal.toFixed(2)}</span>
            </div>

            <Link href="/checkout" className={`btn btn-primary ${styles.checkoutBtn}`}>
              Proceed to Checkout
            </Link>

            <Link href="/shop" className={`btn btn-ghost ${styles.continueBtn}`}>
              Continue Shopping
            </Link>

            <div className={styles.trust}>
              <p>🔒 Secure checkout</p>
              <p>💌 Free handwritten card</p>
              <p>🌿 Sustainably sourced</p>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
