# 🌸 LinaRoos – Luxury Flower Shop

A complete, production-ready Next.js e-commerce website for **LinaRoos**, a luxury floral studio. Built with modern best practices: full SEO, mobile-first responsive design, working cart, checkout flow, and an admin dashboard.

---

## ✨ Features

| Feature | Details |
|---|---|
| **Pages** | Home, Shop, Product Detail, About, Contact, Cart, Checkout, 404 |
| **SEO** | Meta tags, Open Graph, Twitter Card, JSON-LD, Sitemap, robots.txt |
| **Mobile** | Fully responsive, mobile-first CSS, hamburger menu |
| **Cart** | Persistent cart via localStorage, quantity management |
| **Checkout** | Multi-step form with Stripe integration prepared |
| **Admin** | Full dashboard: add/edit/delete products, stock toggle, export JSON |
| **Performance** | Next.js Image optimisation, font preconnect, ISR-ready |

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation

```bash
# 1. Clone or unzip the project
cd linaroos

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.example .env.local
# Edit .env.local with your values

# 4. Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to see the site.

### Admin Panel
Visit [http://localhost:3000/admin](http://localhost:3000/admin)

Default password: `linaroos-admin-2024`

Change it by setting `NEXT_PUBLIC_ADMIN_PASSWORD` in `.env.local`.

---

## 📁 Project Structure

```
linaroos/
├── components/          # Reusable UI components
│   ├── Layout.js        # Page wrapper (Navbar + Footer)
│   ├── Navbar.js        # Responsive navigation with cart badge
│   ├── Footer.js        # Full footer with links & contact
│   ├── ProductCard.js   # Product grid card with quick-add
│   └── SEOHead.js       # Meta / OG / Twitter / JSON-LD injector
│
├── context/
│   └── CartContext.js   # React context for cart (localStorage)
│
├── data/
│   └── products.json    # Product catalogue (edit or export from admin)
│
├── hooks/
│   └── useAdminAuth.js  # Admin session auth hook
│
├── lib/
│   └── seo.js           # SEO config, buildSEO(), JSON-LD schemas
│
├── pages/
│   ├── index.js         # Homepage
│   ├── about.js         # About / Our Story
│   ├── contact.js       # Contact form
│   ├── cart.js          # Shopping cart
│   ├── checkout.js      # Multi-step checkout + Stripe stub
│   ├── sitemap.xml.js   # Dynamic XML sitemap
│   ├── 404.js           # Custom 404 page
│   ├── _app.js          # App wrapper (CartProvider, Layout)
│   ├── _document.js     # HTML document (fonts, lang)
│   ├── shop/
│   │   ├── index.js     # Shop listing with filter/sort/search
│   │   └── [slug].js    # Product detail page
│   ├── admin/
│   │   ├── index.js     # Admin dashboard (CRUD + stats)
│   │   └── login.js     # Admin login
│   └── api/
│       └── create-payment-intent.js  # Stripe API route
│
├── public/
│   ├── robots.txt       # Search engine rules
│   └── site.webmanifest # PWA manifest
│
└── styles/
    ├── globals.css      # Design tokens, base styles, utilities
    ├── Home.module.css
    ├── Shop.module.css
    ├── ProductDetail.module.css
    ├── Cart.module.css
    ├── Checkout.module.css
    ├── About.module.css
    ├── Contact.module.css
    ├── Admin.module.css
    └── AdminLogin.module.css
```

---

## 🌐 Deploy on Vercel

1. Push your project to GitHub / GitLab / Bitbucket
2. Go to [vercel.com](https://vercel.com) and import the repository
3. Add environment variables in the Vercel dashboard (Settings → Environment Variables):

```
NEXT_PUBLIC_SITE_URL        = https://www.linaroos.nl
NEXT_PUBLIC_ADMIN_PASSWORD  = your-secure-password
STRIPE_SECRET_KEY           = sk_live_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY = pk_live_...
```

4. Click **Deploy** — Vercel auto-detects Next.js and sets everything up.

### Custom Domain
In Vercel → Settings → Domains, add `linaroos.nl` and follow the DNS instructions.

---

## 💳 Stripe Integration

### Setup
1. Create a [Stripe account](https://stripe.com)
2. Get your API keys from the [Stripe Dashboard](https://dashboard.stripe.com/apikeys)
3. Add them to `.env.local`:

```env
STRIPE_SECRET_KEY=sk_test_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
```

### How it works
The payment flow is prepared in `pages/checkout.js` and the API route is in `pages/api/create-payment-intent.js`.

To activate live payments, replace the card input fields in `checkout.js` with Stripe's `<CardElement />`:

```bash
npm install @stripe/stripe-js @stripe/react-stripe-js
```

```jsx
// In checkout.js – replace card fields with:
import { loadStripe } from '@stripe/stripe-js'
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js'

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY)

// Wrap your checkout form:
<Elements stripe={stripePromise}>
  <CheckoutForm />
</Elements>
```

---

## 🛠️ Admin Dashboard

Visit `/admin` to manage your shop.

### Features
- **Product list** – searchable, filterable table with all products
- **Add product** – full form with image preview
- **Edit product** – pre-filled form for any existing product
- **Delete product** – with confirmation modal
- **Stock toggle** – one-click in/out of stock
- **Export JSON** – download `products.json` to save permanently
- **Stats** – product count, stock levels, average price
- **Settings** – reset, export, Stripe & env docs

### Making Changes Permanent
Product changes in the admin are saved to `localStorage`. To make them permanent:
1. Click **Export JSON** in the admin
2. Replace `/data/products.json` with the downloaded file
3. Redeploy

---

## 🎨 Design System

### Colors (CSS variables)
```css
--rose:        #c96b7a  /* primary accent */
--gold:        #c9a96e  /* premium accent */
--green:       #4a6741  /* natural accent */
--blush:       #f9e4e6  /* backgrounds */
--cream:       #fdfaf6  /* page background */
--text:        #2c1a1d  /* primary text / dark */
```

### Typography
- **Display**: Cormorant Garamond (serif, elegant)
- **Script**: Great Vibes (logo & accents)
- **Body**: Jost (clean, modern)

---

## 📦 SEO Checklist

- [x] Unique `<title>` and `<meta description>` per page
- [x] Open Graph tags (Facebook / LinkedIn)
- [x] Twitter Card tags
- [x] JSON-LD structured data (Product + LocalBusiness)
- [x] XML Sitemap at `/sitemap.xml`
- [x] `robots.txt` (blocks `/admin/`)
- [x] Canonical URLs
- [x] `<html lang="nl">`
- [x] PWA manifest
- [x] Image alt tags on all images
- [x] Semantic HTML (nav, main, section, article, address)
- [x] aria-labels on interactive elements

---

## 📞 Support

Built for LinaRoos – Luxury Floral Studio  
Bloemenlaan 12, Amsterdam  
hello@linaroos.nl
